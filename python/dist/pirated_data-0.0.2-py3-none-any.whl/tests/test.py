# from pirated_data import functionProvider

from __init__ import *

# print(firstNameGenerator())
print(lastNameGenerator())
# print(fullNameGenerator())
# print(mobileNumberGenerator())
# print(aadharNumberGenerator())
# print(emailIdGenerator())
# print(userIdGenerator())
# print(passwordGenerator(8))
# print(upiIdGenerator())
# print(hairColorGenerator())
# print(genderGenerator())
# print(eyeColorGenerator())
# print(bloodGroupGenerator())
# print(skinColorGenerator())
# print(weightGenerator())
# print(panCardId())
# print(passportNumber())
print(financialCardGenerator())